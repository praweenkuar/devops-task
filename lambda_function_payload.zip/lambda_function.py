def handler(event, context):
    return {


def handler(event, context):
    return {
        "statusCode": 200,
        "body": "Hello from Terraform Lambda!"
    }





